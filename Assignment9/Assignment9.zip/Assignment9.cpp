//******************************************************************
// Template Program
// Programmer: Alan Ngo
// Completed : November 12 2016
// Status    : Complete
//
// This program will be used...
//******************************************************************
/* PROMPT*/
#include <iostream>				// for cin, cout, endl
#include<cmath>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;
class Date
{
	private:
	int month;
	int day;
	int year;
	
	//constructor
	public:
	Date()
	{
		month=1;
		day=1;
		year=2020;
	}
	
	//accessors
	int getMonth()
	{
		return month;
	}
	
	int getDay()
	{
		return day;
	}
	
	int getYear()
	{
		return year;
	}
	
	//modifyers
	void setMonth(int m)
	{
		month=m;
	}
	
	void setDay(int d)
	{
		day=d;
	}
	
	void setYear(int y)
	{
		year=y;
	}
	
	//other functions
	void printInNumbers()
	{
		cout<<month<<"/"<<day<<"/"<<year<<endl;
	}
	
	void printMDY()
	{
		cout<<monthName()<<" "<<day<<", "<<year<<endl;
	}
	
	void printDMY()
	{
		cout<<day<<" "<<monthName()<<" "<<year<<endl;
	}
	
	string monthName()
	{
	string mon[12]={"January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	string name="";
	int i=0;
	bool found=false;
	while (!found&&i<12)
	{
		if (month==(i+1))
		{
			found=true;
		}
		else
		{
			i++;
		}
	}
	name=mon[i];
	return name;	
	}
};
//prototypes
void input(Date &, int&, int&, int&);
void output(Date&);

int main()						
{ 
	Date date;
	int months=0;
	int days=0;
	int years=0;
	
	//processing
	input(date, months, days, years);
	output(date);
 return 0;
}   // end of main function

void input(Date &date, int &months, int&days, int&years)
{
	cout<<"Enter Month between 1-12: ";
	cin>>months;
	//month
	while (months>12||months<1)
	{
		cout<<"Enter a VALID MONTH NUMBER! ";
		cin>>months;
	}
	date.setMonth(months);
	//day
	cout<<"Enter Day between 1-31: ";
	cin>>days;
	while (days>31||days<1)
	{
		cout<<"Enter a VALID DAY NUMBER! ";
		cin>>days;	
	}
	date.setDay(days);
	//year
	cout<<"Enter Year between 1950-2020: ";
	cin>>years;
	while (years>2020||years<1950)
	{
		cout<<"Enter a YEAR BETWEEN 1950 and 2020! ";
		cin>>years;	
	}
	date.setYear(years);	
}//end of input

void output(Date& date)
{
	cout<<"*************************************"<<endl;
	date.printInNumbers();
	date.printMDY();
	date.printDMY();
}//end of output

